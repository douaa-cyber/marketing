require("dotenv").config();
const { Sequelize } = require("sequelize");

const db = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASSWORD,
  {
    dialect: "mysql",
    port: process.env.DB_PORT,
    host: process.env.DB_HOST,
    logging: false,
  }
);
module.exports = db;
